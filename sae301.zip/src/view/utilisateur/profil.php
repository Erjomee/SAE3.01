<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../../assets/css/profil.css">
    <title>profil</title>
</head>
<body>




<form action="" method="POST">

    <div class = "menu">

    </div>

    <div class= "deux">
        <div class="ber">

        </div>
    </div>

    <div class="gros">
        <p>Mon compte</p>
    </div>

    
    <div>
        <legend>Connexion</legend>
        <div>
            <label for="nom">nom:</label>
            <input type="text" name="nom" id="nom">

            <label for="prenom">prenom:</label>
            <input type="text" name="prenom" id="prenom">

            <label for="mail">email:</label>
            <input type="email" name="mail" id="mail">

            <label for="passwrd">password:</label>
            <input type="password" name="passwrd" id="passwrd">

            <label for="sexe">sexe:</label>
            <input type="text" name="sexe" id="sexe">

            <input type="submit" value="valider">
        </div>
    </div>

    <div>
        <div>
            <label for="desc">A propos de moi: </label>
            <input type="text" name="desc" id="desc">
        </div>
    </div>

    <footer>


    </footer>

</form>
</body>
</html>